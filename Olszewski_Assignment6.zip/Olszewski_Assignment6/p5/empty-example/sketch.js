function setup() {
	createCanvas(600, 600);
	background(150);
	angleMode(RADIANS);
}

function draw() {
	
	// Background (smaller) raindrops
	raindrop(40, 110);
	raindrop(280, 110);
	raindrop(520, 110);
	
	raindrop(40, 310);
	raindrop(280, 310);
	raindrop(520, 310);
	
	raindrop(40, 510);
	raindrop(280, 510);
	raindrop(520, 510);
	
	// Foreground (larger) raindrops + scale / translate / rotate requirements
	scale(1.5);	
	translate(0, -200);	
	rotate(PI / 12.0);

	raindrop(140, 210);
	raindrop(280, 210);
	raindrop(420, 210);
	
	raindrop(140, 410);
	raindrop(280, 410);
	raindrop(420, 410);
	
	raindrop(140, 610);
	raindrop(280, 610);
	raindrop(420, 610);
	
}

function raindrop(x, y) {

	push(); // push requirement

	translate(x, y);

	noStroke();

	fill('blue');

	arc(0, -65, 70, 70, 0, PI); //bottom of raindrop
	
	triangle (-35, -65, 35, -65, 0, -150); //top of raindrop
	
	pop(); // pop requirement

}