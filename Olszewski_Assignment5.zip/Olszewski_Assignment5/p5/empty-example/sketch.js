var x = 505;

var y = 315;

var w = 20;

var h = 10;

var sx = 275;

var sy = 315;

var sw = 210;

var sh = 145;

var kx = 515;

var ky = 375;

var kr = 10;

function setup() {
	createCanvas(800, 600);
	background('beige');
	colorMode(RGB);
}

function draw() {
	//floor
	fill('lightgray');
	strokeWeight(2);
	stroke('black');
	beginShape();
	vertex(0, 600);
	vertex(200, 550);
	vertex(600, 550);
	vertex(800, 600);
	endShape(CLOSE);
	
	//wall corners
	noFill();
	line(200, 550, 200, 0);
	line(600, 550, 600, 0);
	
	//tv stand
	fill(50, 50, 50);
	beginShape();
	vertex(250, 575);
	vertex(250, 475);
	vertex(550, 475);
	vertex(550, 575);
	endShape(CLOSE);
	
	//tv case
	fill (100, 75, 0);
	beginShape();
	vertex (260, 475);
	vertex (260, 300);
	vertex (540, 300);
	vertex (540, 475);
	endShape (CLOSE);
	
	//tv button panel
	fill (100, 100, 100);
	beginShape();
	vertex (500, 310);
	vertex (530, 310);
	vertex (530, 465);
	vertex (500, 465);
	endShape (CLOSE);
	
	//tv screen edge
	fill (100, 100, 100);
	beginShape();
	vertex (270, 310);
	vertex (490, 310);
	vertex (490, 465);
	vertex (270, 465);
	endShape (CLOSE);
	
	//tv screen
	fill (25, 25, 25);
	rect (sx, sy, sw, sh);
	
	//power button
	fill (150, 150, 150);
	rect (x, y, w, h);
	
	//channel knob
	var r = dist(mouseX, mouseY, kx, ky);
	
	ellipseMode(RADIUS);
	fill (150, 150, 150);
	ellipse (kx, ky, kr, kr);
	
	//change channel
	if (keyIsPressed) {
		
		if ( key == 'a' )
			if  (r < kr){
			fill (250, 0, 0);
			rect (sx, sy, sw, sh);
			}
	}
	
	if (keyIsPressed) {
		
		if ( key == 'd' )
			if  (r < kr){
			fill (0, 250, 0);
			rect (sx, sy, sw, sh);
			}
	}
	//power button
	if (mouseIsPressed) {
		if ((mouseX > x) && (mouseX < x+w) && (mouseY > y) && (mouseY < y+h)) {
			
		fill (50, 50, 50);
		rect (x, y, w, h);
		
		fill (200, 200, 200);
		rect (sx, sy, sw, sh);
		}
	}
}