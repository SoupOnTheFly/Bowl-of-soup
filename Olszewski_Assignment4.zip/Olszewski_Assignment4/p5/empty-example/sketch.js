let value = 50;

function setup() {
	createCanvas(800, 600);
	strokeWeight (5);
}


/*This isn't behaving the way I expect it to, but I guess it's still working.
	I was expecting the strokeWeight change to be permanent. Instead it just flashes.
	If you could give me feedback on what I'm doing wrong here, I'd appreciate it!
	Also, is there a command to set a timer in seconds? For example, could I
	cause the strokeWeight to change for 5 seconds and revert?*/
	
function mousePressed() {
	if (value == 50) {
		strokeWeight (10);
	}
}

function draw() {
  background(50);
  
    /*Didn't know how to incorporate this in an aesthetically pleasing and coherent manner.
		I guess it looks alright. */
		
	stroke('gray');	
  for (var x = 5; x < 1000; x += 60) {
  	line(x - 500, 0, x + 600, 800);
  }
	
	/* Use the "W A S D" keys to create arrows in the corresponding directions.
		Mouse click also creates an effect. */
		
  stroke('white');
  strokeWeight(30);
  
  if (keyIsPressed) {
	//up
  	if (key == 'w') {
  		line(400, 100, 400, 500);
		line(400, 100, 350, 150);
		line(400, 100, 450, 150);
  	} 
	//left
    else if ( key == 'a') {
  		line (200, 300, 600, 300);
		line (200, 300, 250, 350);
		line (200, 300, 250, 250);
  	}
	//down
	else if ( key == 's') {
  		line(400, 100, 400, 500);
		line(400, 500, 350, 450);
		line(400, 500, 450, 450);
  	}
	//right
	else if ( key == 'd') {
  		line (200, 300, 600, 300);
		line (600, 300, 550, 250);
		line (600, 300, 550, 350);
  	}
  } 
}